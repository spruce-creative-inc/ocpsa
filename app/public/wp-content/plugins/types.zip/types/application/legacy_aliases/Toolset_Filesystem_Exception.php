<?php

use OTGS\Toolset\Types\Filesystem\Exception;

if ( false ) {
	/** @deprecated  */
	class Toolset_Filesystem_Exception extends Exception { }
}

class_exists( Exception::class );
