<?php

/**
 * Interface Types_Interop_Handler_Interface
 *
 * See OTGS\Toolset\Types\Controller\Interop\InteropMediator for details.
 *
 * @since 2.2.7
 */
interface Types_Interop_Handler_Interface {

	public static function initialize();

}
