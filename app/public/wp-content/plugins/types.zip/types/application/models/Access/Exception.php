<?php

namespace OTGS\Toolset\Types\Access;

/**
 * Class Exception
 * @package OTGS\Toolset\Types\Access
 *
 * @since 3.2
 */
class Exception extends \Exception {}