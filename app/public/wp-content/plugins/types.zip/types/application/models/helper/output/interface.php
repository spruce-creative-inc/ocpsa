<?php

/**
 * Types_Helper_Output_Interface
 *
 * @since 2.0
 */
interface Types_Helper_Output_Interface {
	public function set_content( $content );
	public function output();
}