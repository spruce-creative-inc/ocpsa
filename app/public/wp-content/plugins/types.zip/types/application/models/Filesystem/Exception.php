<?php
namespace OTGS\Toolset\Types\Filesystem;

class Exception extends \Exception {

}

/** @noinspection PhpIgnoredClassAliasDeclaration */
class_alias( \OTGS\Toolset\Types\Filesystem\Exception::class, 'Toolset_Filesystem_Exception' );
